﻿namespace EmployeeApp
{
    // Employee class that inherits from Person
    public class Employee : Person
    {
        // Property for the employee's ID
        public int Id { get; set; }
    }
}
